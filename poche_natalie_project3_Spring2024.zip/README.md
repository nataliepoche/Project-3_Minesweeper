Name: Natalie Poche
Section: 10831
UFL email: n.poche@ufl.edu
System: Windows 11
Compiler: MinGW64
SFML Version: 2.5.1
IDE: CLion 2023.3.2
Other Notes: When running, I needed to run it as the entire project, it wouldn't work if I just ran the main.cpp.